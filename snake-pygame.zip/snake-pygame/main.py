import pygame
import random
import sys


# ============================================================
# CONFIGURAÇÕES DO JOGO
# ============================================================

# Inicializa todos os módulos necessários do Pygame.
pygame.init()

# Tamanho da janela do jogo.
LARGURA = 800
ALTURA = 600

# Tamanho de cada parte da cobra e também da grade do jogo.
# Trabalhar com uma grade facilita a movimentação e as colisões.
TAMANHO_BLOCO = 20

# Quantidade de blocos existentes horizontal e verticalmente.
COLUNAS = LARGURA // TAMANHO_BLOCO
LINHAS = ALTURA // TAMANHO_BLOCO

# Cria a janela principal.
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Snake - Jogo da Cobrinha")

# Controla a quantidade de atualizações do jogo por segundo.
# Um valor maior deixa a cobra mais rápida.
FPS = 9

# Relógio usado para controlar a velocidade do jogo.
relogio = pygame.time.Clock()


# ============================================================
# CORES
# ============================================================

PRETO = (20, 20, 20)
BRANCO = (255, 255, 255)
VERDE = (0, 200, 80)
VERDE_ESCURO = (0, 140, 50)
VERMELHO = (220, 50, 50)
CINZA = (80, 80, 80)


# ============================================================
# FONTES
# ============================================================

fonte_pontuacao = pygame.font.Font(None, 32)
fonte_game_over = pygame.font.Font(None, 72)
fonte_instrucoes = pygame.font.Font(None, 36)


# ============================================================
# FUNÇÃO PARA GERAR A COMIDA
# ============================================================

def gerar_comida(cobra):
    """
    Gera uma nova posição aleatória para a comida.

    A comida é criada dentro da grade do jogo.
    Também verificamos se a posição escolhida não está
    ocupada pela cobra, evitando que a comida apareça
    dentro do corpo dela.
    """

    while True:
        x = random.randint(0, COLUNAS - 1)
        y = random.randint(0, LINHAS - 1)

        nova_comida = (x, y)

        if nova_comida not in cobra:
            return nova_comida


# ============================================================
# FUNÇÃO PARA DESENHAR UM BLOCO
# ============================================================

def desenhar_bloco(posicao, cor):
    """
    Converte uma posição da grade em coordenadas da tela
    e desenha um quadrado.

    Por exemplo:
    posição (5, 3) significa coluna 5 e linha 3.

    Isso permite que a cobra se movimente de bloco em bloco,
    evitando movimentos quebrados ou difíceis de controlar.
    """

    x, y = posicao

    retangulo = pygame.Rect(
        x * TAMANHO_BLOCO,
        y * TAMANHO_BLOCO,
        TAMANHO_BLOCO,
        TAMANHO_BLOCO
    )

    pygame.draw.rect(tela, cor, retangulo)


# ============================================================
# FUNÇÃO PARA DESENHAR A COBRA
# ============================================================

def desenhar_cobra(cobra):
    """
    Desenha todos os segmentos da cobra.

    O primeiro elemento da lista representa a cabeça.
    Os demais elementos representam o corpo.
    """

    for i, parte in enumerate(cobra):

        # A cabeça recebe uma cor diferente para facilitar
        # a visualização da direção da cobra.
        if i == 0:
            desenhar_bloco(parte, VERDE_ESCURO)
        else:
            desenhar_bloco(parte, VERDE)


# ============================================================
# FUNÇÃO PARA MOSTRAR A PONTUAÇÃO
# ============================================================

def desenhar_pontuacao(pontuacao):
    """
    Exibe a pontuação no canto superior esquerdo da janela.
    """

    texto = fonte_pontuacao.render(
        f"Pontuação: {pontuacao}",
        True,
        BRANCO
    )

    tela.blit(texto, (10, 10))


# ============================================================
# FUNÇÃO PARA EXIBIR O GAME OVER
# ============================================================

def mostrar_game_over(pontuacao):
    """
    Exibe a tela de Game Over.

    O jogador pode pressionar R para iniciar uma nova partida
    ou ESC para fechar o jogo.
    """

    # Cria uma superfície transparente para escurecer a tela.
    camada = pygame.Surface((LARGURA, ALTURA))
    camada.set_alpha(180)
    camada.fill(PRETO)

    tela.blit(camada, (0, 0))

    # Texto principal.
    texto_game_over = fonte_game_over.render(
        "GAME OVER",
        True,
        VERMELHO
    )

    rect_game_over = texto_game_over.get_rect(
        center=(LARGURA // 2, ALTURA // 2 - 60)
    )

    tela.blit(texto_game_over, rect_game_over)

    # Mostra a pontuação final.
    texto_pontuacao = fonte_instrucoes.render(
        f"Pontuação final: {pontuacao}",
        True,
        BRANCO
    )

    rect_pontuacao = texto_pontuacao.get_rect(
        center=(LARGURA // 2, ALTURA // 2 + 10)
    )

    tela.blit(texto_pontuacao, rect_pontuacao)

    # Instrução para reiniciar.
    texto_reiniciar = fonte_instrucoes.render(
        "Pressione R para jogar novamente",
        True,
        BRANCO
    )

    rect_reiniciar = texto_reiniciar.get_rect(
        center=(LARGURA // 2, ALTURA // 2 + 60)
    )

    tela.blit(texto_reiniciar, rect_reiniciar)


# ============================================================
# FUNÇÃO PARA INICIAR/REINICIAR UMA PARTIDA
# ============================================================

def iniciar_jogo():
    """
    Cria os valores iniciais de uma nova partida.

    Retorna a cobra, direção, comida, pontuação e estado
    inicial do jogo.
    """

    # Começamos com três segmentos.
    cobra = [
        (COLUNAS // 2, LINHAS // 2),
        (COLUNAS // 2 - 1, LINHAS // 2),
        (COLUNAS // 2 - 2, LINHAS // 2)
    ]

    # A cobra começa se movimentando para a direita.
    direcao = (1, 0)

    # A direção que será aplicada no próximo movimento.
    proxima_direcao = direcao

    # Gera a primeira comida.
    comida = gerar_comida(cobra)

    # Pontuação inicial.
    pontuacao = 0

    # Indica se a partida está acontecendo.
    game_over = False

    return cobra, direcao, proxima_direcao, comida, pontuacao, game_over


# ============================================================
# INICIALIZAÇÃO DA PRIMEIRA PARTIDA
# ============================================================

(
    cobra,
    direcao,
    proxima_direcao,
    comida,
    pontuacao,
    game_over
) = iniciar_jogo()


# ============================================================
# LOOP PRINCIPAL DO JOGO
# ============================================================

while True:

    # --------------------------------------------------------
    # CAPTURA DOS EVENTOS
    # --------------------------------------------------------

    for evento in pygame.event.get():

        # Evento responsável por fechar a janela.
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        # Verifica se alguma tecla foi pressionada.
        if evento.type == pygame.KEYDOWN:

            # ESC fecha o jogo em qualquer momento.
            if evento.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()

            # ------------------------------------------------
            # CONTROLES DURANTE A PARTIDA
            # ------------------------------------------------

            if not game_over:

                # Setas direcionais.
                #
                # A verificação abaixo impede que a cobra
                # faça uma curva de 180 graus e bata nela mesma
                # imediatamente.
                if evento.key == pygame.K_UP and direcao != (0, 1):
                    proxima_direcao = (0, -1)

                elif evento.key == pygame.K_DOWN and direcao != (0, -1):
                    proxima_direcao = (0, 1)

                elif evento.key == pygame.K_LEFT and direcao != (1, 0):
                    proxima_direcao = (-1, 0)

                elif evento.key == pygame.K_RIGHT and direcao != (-1, 0):
                    proxima_direcao = (1, 0)

                # Também permitimos WASD.
                elif evento.key == pygame.K_w and direcao != (0, 1):
                    proxima_direcao = (0, -1)

                elif evento.key == pygame.K_s and direcao != (0, -1):
                    proxima_direcao = (0, 1)

                elif evento.key == pygame.K_a and direcao != (1, 0):
                    proxima_direcao = (-1, 0)

                elif evento.key == pygame.K_d and direcao != (-1, 0):
                    proxima_direcao = (1, 0)

            # ------------------------------------------------
            # REINICIAR APÓS GAME OVER
            # ------------------------------------------------

            else:

                # Pressionar R cria uma nova partida.
                if evento.key == pygame.K_r:

                    (
                        cobra,
                        direcao,
                        proxima_direcao,
                        comida,
                        pontuacao,
                        game_over
                    ) = iniciar_jogo()


    # ========================================================
    # ATUALIZAÇÃO DA LÓGICA DO JOGO
    # ========================================================

    if not game_over:

        # Atualiza a direção atual somente quando o jogo
        # realmente vai realizar um novo movimento.
        direcao = proxima_direcao

        # Pega a posição atual da cabeça.
        cabeca_x, cabeca_y = cobra[0]

        # Calcula a nova posição da cabeça.
        nova_cabeca = (
            cabeca_x + direcao[0],
            cabeca_y + direcao[1]
        )

        # ----------------------------------------------------
        # COLISÃO COM AS PAREDES
        # ----------------------------------------------------

        # Se a cabeça sair dos limites da grade, o jogo termina.
        if (
            nova_cabeca[0] < 0
            or nova_cabeca[0] >= COLUNAS
            or nova_cabeca[1] < 0
            or nova_cabeca[1] >= LINHAS
        ):
            game_over = True

        # ----------------------------------------------------
        # COLISÃO COM O PRÓPRIO CORPO
        # ----------------------------------------------------

        elif nova_cabeca in cobra:
            game_over = True

        else:

            # Insere a nova cabeça no início da lista.
            cobra.insert(0, nova_cabeca)

            # ------------------------------------------------
            # VERIFICAÇÃO DA COMIDA
            # ------------------------------------------------

            if nova_cabeca == comida:

                # Ao comer, a cauda NÃO é removida.
                # Dessa maneira a cobra passa a ter um segmento
                # a mais, representando seu crescimento.
                pontuacao += 1

                # Gera uma nova comida em outra posição.
                comida = gerar_comida(cobra)

            else:

                # Quando não comeu, removemos o último segmento.
                #
                # Assim a quantidade de segmentos permanece igual
                # e temos a impressão de que a cobra está andando.
                cobra.pop()


    # ========================================================
    # DESENHO DA TELA
    # ========================================================

    # Limpa a tela a cada atualização para desenhar
    # novamente os elementos nas novas posições.
    tela.fill(PRETO)

    # Desenha uma grade discreta para deixar o movimento
    # baseado nos blocos mais fácil de visualizar.
    for x in range(0, LARGURA, TAMANHO_BLOCO):
        pygame.draw.line(
            tela,
            CINZA,
            (x, 0),
            (x, ALTURA)
        )

    for y in range(0, ALTURA, TAMANHO_BLOCO):
        pygame.draw.line(
            tela,
            CINZA,
            (0, y),
            (LARGURA, y)
        )

    # Desenha a comida.
    desenhar_bloco(comida, VERMELHO)

    # Desenha a cobra.
    desenhar_cobra(cobra)

    # Desenha a pontuação.
    desenhar_pontuacao(pontuacao)

    # Se ocorreu Game Over, coloca a mensagem por cima
    # dos elementos do jogo.
    if game_over:
        mostrar_game_over(pontuacao)

    # Atualiza tudo que foi desenhado na janela.
    pygame.display.flip()

    # Controla a velocidade do jogo.
    relogio.tick(FPS)